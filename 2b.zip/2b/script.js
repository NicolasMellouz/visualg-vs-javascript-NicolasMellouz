function parimpar(){
var n = prompt("Digite um numero");
var total = n/2;
    
if(n & 1){
    alert("Impar");
} else {
    alert("Par");
 }
    

}